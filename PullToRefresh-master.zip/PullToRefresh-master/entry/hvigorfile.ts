import { hapTasks } from '@ohos/hvigor-ohos-plugin';
import { AppRouterPlugin } from "app_router_hvigor_plugin"

export default {
  system: hapTasks,

  plugins: [AppRouterPlugin({
    "isEntry": true, "routerDependencyName": "@zhongrui/app_router", "scanPackagePath": ["src/main/ets"]
  })]
}
