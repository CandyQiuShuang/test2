# Changelog

## [v1.0.1] 2024-08

### 🐞Bug修复

* JSONObject.parseObject新增是否转换日期字符串为日期对象开关[issuesIAKSEQ](https://gitee.com/yunkss/ef-tool/issues/IAKSEQ)

## [v1.0.0] 2024-08

### 🐣新特性

* 发布正式版本

### 🐞Bug修复

* 暂无