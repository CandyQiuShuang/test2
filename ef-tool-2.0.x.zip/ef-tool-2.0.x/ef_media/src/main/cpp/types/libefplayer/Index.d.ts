export const add: (a: number, b: number) => number;

// export const getVersion => number;