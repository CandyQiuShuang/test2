# Changelog

## [v1.0.5] 2024-09

### 🐞Bug修复

* 优化请求中使用as转换导致调用泛型方法报错,以及状态变量刷新UI问题

## [v1.0.4] 2024-09

### 🐞Bug修复

* 优化upload上传文件同时支持表单信息[issuesIASJA8](https://gitee.com/yunkss/ef-tool/issues/IASJA8)

## [v1.0.3] 2024-08

### 🐞Bug修复

* 优化支持多baseURL和设置公共请求头[感谢coffey的pull Request](https://gitee.com/coffey)

## [v1.0.2] 2024-08

### 🐞Bug修复

* 完善开源协议,添加NOTICE

## [v1.0.1] 2024-08

### 🐞Bug修复

* 修复全局loading在并发请求时报错导致无法关闭问题

## [v1.0.0] 2024-08

### 🐣新特性

* 发布正式版本

### 🐞Bug修复

* 暂无